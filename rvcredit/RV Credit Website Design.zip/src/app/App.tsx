import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Benefits } from './components/Benefits';
import { HowItWorks } from './components/HowItWorks';
import { LoanCalculator } from './components/LoanCalculator';
import { RatesTable } from './components/RatesTable';
import { Financing } from './components/Financing';
import { Testimonials } from './components/Testimonials';
import { CTA } from './components/CTA';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="rv-app">
      <Header />
      <main>
        <Hero />
        <Benefits />
        <HowItWorks />
        <LoanCalculator />
        <RatesTable />
        <Financing />
        <Testimonials />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
