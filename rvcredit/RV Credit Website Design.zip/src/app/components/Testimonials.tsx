import React from 'react';
import { Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import './Testimonials.css';

const testimonials = [
  {
    name: 'Robert & Linda M.',
    location: 'Phoenix, AZ',
    rating: 5,
    text: 'We were nervous about financing our first RV, but the team at RV Credit made everything so easy. The process was straightforward, and we got approved faster than we expected. Now we\'re enjoying retirement on the road!',
    image: 'https://images.unsplash.com/photo-1574884280706-7342ca3d4231?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjBhZHZpc29yJTIwY29uc3VsdGF0aW9ufGVufDF8fHx8MTc2MTY2OTkxMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    name: 'Michael T.',
    location: 'Denver, CO',
    rating: 5,
    text: 'As a first-time buyer, I had lots of questions. The financing specialists were patient and explained everything clearly. They found me a great rate on a used fifth wheel that fits my budget perfectly.',
    image: 'https://images.unsplash.com/photo-1661220715153-95724e5f3500?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBtb3RvcmhvbWUlMjBpbnRlcmlvcnxlbnwxfHx8fDE3NjE3NzE5NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    name: 'Sarah K.',
    location: 'Portland, OR',
    rating: 5,
    text: 'I wasn\'t sure if I could get approved with my credit score, but RV Credit worked with me and found financing options that worked. Three months later, I\'m living my dream of full-time RV travel!',
    image: 'https://images.unsplash.com/photo-1634756124201-cc9e604c53ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzcyUyMGElMjBtb3RvcmhvbWUlMjByb2FkfGVufDF8fHx8MTc2MTc3MTk1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

export function Testimonials() {
  return (
    <section className="rv-section">
      <div className="rv-container">
        <div className="rv-testimonials-header">
          <h2 className="rv-heading-lg rv-heading-serif">What Our Customers Say</h2>
          <p className="rv-text-lg">
            Don't just take our word for it. Hear from RV buyers who've successfully 
            financed their dream vehicles with RV Credit.
          </p>
        </div>
        <div className="rv-testimonials-grid">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="rv-testimonial-card">
              <div className="rv-testimonial-rating">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} size={18} fill="var(--rv-accent)" color="var(--rv-accent)" />
                ))}
              </div>
              <p className="rv-testimonial-text">"{testimonial.text}"</p>
              <div className="rv-testimonial-author">
                <ImageWithFallback
                  src={testimonial.image}
                  alt={`${testimonial.name} - satisfied RV Credit customer`}
                  className="rv-testimonial-avatar"
                />
                <div className="rv-testimonial-info">
                  <div className="rv-testimonial-name">{testimonial.name}</div>
                  <div className="rv-testimonial-location">{testimonial.location}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
