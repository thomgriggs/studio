import React, { useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import './Header.css';
import RVCreditLogo from './rv-credit-logo.svg';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="rv-header">
      <div className="rv-container">
        <nav className="rv-nav">
          <div className="rv-logo">
            <a href="/" aria-label="RV Credit Home">
              <img src={RVCreditLogo} alt="RV Credit" className="rv-logo-image" />
            </a>
          </div>

          <button
            className="rv-mobile-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle mobile menu"
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <ul className={`rv-nav-links ${mobileMenuOpen ? 'rv-nav-open' : ''}`}>
            <li><a href="#financing">Financing Options</a></li>
            <li><a href="#how-it-works">How It Works</a></li>
            <li><a href="#about">About Us</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li className="rv-nav-cta">
              <a href="#apply" className="rv-btn rv-btn-primary">
                <Phone size={18} />
                <span>Apply Now</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
