import React from 'react';
import { TrendingDown, Clock, Shield, CheckCircle, Users, Zap } from 'lucide-react';
import './Benefits.css';

const benefits = [
  {
    icon: TrendingDown,
    title: 'Competitive Rates',
    description: 'Access some of the most competitive rates in the RV financing industry, tailored to your financial situation.'
  },
  {
    icon: Clock,
    title: 'Quick Approvals',
    description: 'Get pre-approved in minutes with our streamlined application process. No waiting weeks for an answer.'
  },
  {
    icon: Shield,
    title: 'Flexible Terms',
    description: 'Choose loan terms from 5 to 20 years that work best for your budget and lifestyle goals.'
  },
  {
    icon: CheckCircle,
    title: 'Simple Process',
    description: 'Our straightforward application makes financing easy, even if you\'re a first-time RV buyer.'
  },
  {
    icon: Users,
    title: 'Expert Support',
    description: 'Work with experienced financing specialists who understand the RV market and your needs.'
  },
  {
    icon: Zap,
    title: 'Fast Funding',
    description: 'Once approved, receive funding quickly so you can start your adventures without delay.'
  }
];

export function Benefits() {
  return (
    <section className="rv-section rv-section-alt">
      <div className="rv-container">
        <div className="rv-benefits-header">
          <h2 className="rv-heading-lg rv-heading-serif">Why Choose RV Credit?</h2>
          <p className="rv-text-lg">
            We specialize in RV financing and understand what matters most to RV buyers. 
            Here's what sets us apart.
          </p>
        </div>
        <div className="rv-benefits-grid">
          {benefits.map((benefit, index) => {
            const IconComponent = benefit.icon;
            return (
              <div key={index} className="rv-benefit-card">
                <div className="rv-benefit-icon">
                  <IconComponent size={32} strokeWidth={1.5} />
                </div>
                <h3 className="rv-benefit-title">{benefit.title}</h3>
                <p className="rv-benefit-description">{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
