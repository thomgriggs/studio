import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import './Financing.css';

export function Financing() {
  return (
    <section className="rv-section rv-section-alt" id="financing">
      <div className="rv-container">
        <div className="rv-financing-grid">
          <div className="rv-financing-image">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1758518729593-275baa967f78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjBwbGFubmluZyUyMG1lZXRpbmd8ZW58MXx8fHwxNzYxNzQ2ODkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Financial planning meeting for RV loan"
              className="rv-financing-img"
            />
          </div>
          <div className="rv-financing-content">
            <h2 className="rv-heading-lg rv-heading-serif">Financing Options for Every Budget</h2>
            <p className="rv-text-base">
              At RV Credit, we understand that every buyer's situation is unique. That's why we 
              offer flexible financing solutions for new RVs, used RVs, and refinancing.
            </p>
            <div className="rv-financing-features">
              <div className="rv-feature-item">
                <div className="rv-feature-check">✓</div>
                <div className="rv-feature-text">
                  <strong>Loan amounts</strong> from $10,000 to $500,000
                </div>
              </div>
              <div className="rv-feature-item">
                <div className="rv-feature-check">✓</div>
                <div className="rv-feature-text">
                  <strong>Terms</strong> ranging from 5 to 20 years
                </div>
              </div>
              <div className="rv-feature-item">
                <div className="rv-feature-check">✓</div>
                <div className="rv-feature-text">
                  <strong>Competitive rates</strong> starting as low as 5.99% APR
                </div>
              </div>
              <div className="rv-feature-item">
                <div className="rv-feature-check">✓</div>
                <div className="rv-feature-text">
                  <strong>No prepayment penalties</strong> – pay off early without fees
                </div>
              </div>
              <div className="rv-feature-item">
                <div className="rv-feature-check">✓</div>
                <div className="rv-feature-text">
                  <strong>Credit challenges?</strong> We have options that may work for you.
                </div>
              </div>
              <div className="rv-feature-item">
                <div className="rv-feature-check">✓</div>
                <div className="rv-feature-text">
                  <strong>Low down payment options</strong> available
                </div>
              </div>
            </div>
            <a href="#apply" className="rv-btn rv-btn-primary">
              Explore Financing Options
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
