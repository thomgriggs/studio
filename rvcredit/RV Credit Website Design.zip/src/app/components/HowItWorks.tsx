import React, { useState } from 'react';
import { FileText, Search, DollarSign, Key } from 'lucide-react';
import './HowItWorks.css';

const steps = [
  {
    number: '01',
    icon: FileText,
    title: 'Submit Application',
    description: 'Complete our simple online application in just a few minutes. We only ask for essential information.'
  },
  {
    number: '02',
    icon: Search,
    title: 'Review & Approval',
    description: 'Our team reviews your application and provides a pre-approval decision, often within the same day.'
  },
  {
    number: '03',
    icon: DollarSign,
    title: 'Choose Your RV',
    description: 'Shop confidently knowing your budget. Find the perfect RV that fits your financing terms.'
  },
  {
    number: '04',
    icon: Key,
    title: 'Finalize & Drive',
    description: 'Complete the paperwork, finalize your loan, and start creating memories on the open road.'
  }
];

export function HowItWorks() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section className="rv-section" id="how-it-works">
      <div className="rv-container">
        <div className="rv-how-header">
          <h2 className="rv-heading-lg rv-heading-serif">How It Works</h2>
          <p className="rv-text-lg">
            Getting financed for your RV is easier than you think. 
            Follow these four simple steps to get on the road.
          </p>
        </div>
        <div className="rv-timeline">
          {steps.map((step, index) => {
            const IconComponent = step.icon;
            const isHovered = hoveredIndex === index;
            const isDimmed = hoveredIndex !== null && hoveredIndex !== index;
            
            return (
              <div 
                key={index} 
                className={`rv-timeline-item ${isDimmed ? 'dimmed' : ''}`}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className="rv-timeline-marker">
                  <div className="rv-timeline-number">{step.number}</div>
                  <div className="rv-timeline-icon">
                    <IconComponent size={24} strokeWidth={2} />
                  </div>
                </div>
                <div className="rv-timeline-content">
                  <h3 className="rv-step-title">{step.title}</h3>
                  <p className="rv-step-description">{step.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
