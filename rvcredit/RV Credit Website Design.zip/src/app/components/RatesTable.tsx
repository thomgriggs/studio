import React, { useState } from 'react';
import './RatesTable.css';

const ratesData = {
  new: [
    { amount: '$10,000 - $24,999', rate: '5.99% - 7.49%', term: 'Up to 144 months' },
    { amount: '$25,000 - $49,999', rate: '5.79% - 7.29%', term: 'Up to 180 months' },
    { amount: '$50,000 - $99,999', rate: '5.59% - 7.09%', term: 'Up to 240 months' },
    { amount: '$100,000 - $249,999', rate: '5.49% - 6.99%', term: 'Up to 240 months' },
    { amount: '$250,000+', rate: '5.39% - 6.89%', term: 'Up to 240 months' }
  ],
  used: [
    { amount: '$10,000 - $24,999', rate: '6.49% - 8.49%', term: 'Up to 120 months' },
    { amount: '$25,000 - $49,999', rate: '6.29% - 8.29%', term: 'Up to 144 months' },
    { amount: '$50,000 - $99,999', rate: '6.09% - 8.09%', term: 'Up to 180 months' },
    { amount: '$100,000 - $249,999', rate: '5.99% - 7.99%', term: 'Up to 180 months' },
    { amount: '$250,000+', rate: '5.89% - 7.89%', term: 'Up to 180 months' }
  ],
  refinance: [
    { amount: '$10,000 - $24,999', rate: '6.99% - 8.99%', term: 'Up to 120 months' },
    { amount: '$25,000 - $49,999', rate: '6.79% - 8.79%', term: 'Up to 144 months' },
    { amount: '$50,000 - $99,999', rate: '6.59% - 8.59%', term: 'Up to 180 months' },
    { amount: '$100,000 - $249,999', rate: '6.49% - 8.49%', term: 'Up to 180 months' },
    { amount: '$250,000+', rate: '6.39% - 8.39%', term: 'Up to 180 months' }
  ]
};

type RateType = 'new' | 'used' | 'refinance';

export function RatesTable() {
  const [activeTab, setActiveTab] = useState<RateType>('new');

  return (
    <section className="rv-section" id="rates">
      <div className="rv-container">
        <div className="rv-rates-header">
          <h2 className="rv-heading-lg rv-heading-serif">RV Financing Rates</h2>
          <p className="rv-text-lg">
            Competitive rates for new RVs, used RVs, and refinancing. Rates shown are estimates 
            and may vary based on creditworthiness, loan amount, and other factors.
          </p>
        </div>

        <div className="rv-rates-tabs">
          <button
            className={`rv-rate-tab ${activeTab === 'new' ? 'active' : ''}`}
            onClick={() => setActiveTab('new')}
          >
            New RVs
          </button>
          <button
            className={`rv-rate-tab ${activeTab === 'used' ? 'active' : ''}`}
            onClick={() => setActiveTab('used')}
          >
            Used RVs
          </button>
          <button
            className={`rv-rate-tab ${activeTab === 'refinance' ? 'active' : ''}`}
            onClick={() => setActiveTab('refinance')}
          >
            Refinancing
          </button>
        </div>

        <div className="rv-rates-table-container">
          <table className="rv-rates-table">
            <thead>
              <tr>
                <th>Loan Amount</th>
                <th>Rate Range (APR)</th>
                <th>Maximum Term</th>
              </tr>
            </thead>
            <tbody>
              {ratesData[activeTab].map((row, index) => (
                <tr key={index}>
                  <td>{row.amount}</td>
                  <td><strong>{row.rate}</strong></td>
                  <td>{row.term}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="rv-rates-disclaimer">
          <p>
            <strong>Important:</strong> Rates shown are for illustration purposes only and subject to change. 
            Actual rates depend on credit score, loan-to-value ratio, loan term, and other underwriting factors. 
            All applications subject to credit approval. Terms and conditions apply.
          </p>
        </div>
      </div>
    </section>
  );
}
