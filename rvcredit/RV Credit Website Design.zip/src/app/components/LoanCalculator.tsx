import React, { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import './LoanCalculator.css';

// Rate lookup table: [loanType][creditScoreRange] => { baseRate, term }
const rateLookup: Record<string, Record<string, { baseRate: number; term: number }>> = {
  new: {
    '760-850': { baseRate: 5.99, term: 240 },
    '700-759': { baseRate: 6.49, term: 240 },
    '660-699': { baseRate: 7.29, term: 180 },
    '620-659': { baseRate: 8.49, term: 180 },
    '580-619': { baseRate: 9.99, term: 144 },
    '500-579': { baseRate: 11.99, term: 144 }
  },
  used: {
    '760-850': { baseRate: 6.49, term: 180 },
    '700-759': { baseRate: 6.99, term: 180 },
    '660-699': { baseRate: 7.79, term: 144 },
    '620-659': { baseRate: 8.99, term: 144 },
    '580-619': { baseRate: 10.49, term: 120 },
    '500-579': { baseRate: 12.49, term: 120 }
  },
  refinance: {
    '760-850': { baseRate: 6.99, term: 180 },
    '700-759': { baseRate: 7.49, term: 180 },
    '660-699': { baseRate: 8.29, term: 144 },
    '620-659': { baseRate: 9.49, term: 144 },
    '580-619': { baseRate: 10.99, term: 120 },
    '500-579': { baseRate: 12.99, term: 120 }
  }
};

const modelYears = Array.from({ length: 26 }, (_, i) => 2025 - i);

const loanTypeOptions = [
  { value: 'new', label: 'New RV', description: 'Finance a brand new RV', className: 'loan-type-1' },
  { value: 'used', label: 'Used RV', description: 'Finance a pre-owned RV', className: 'loan-type-2' },
  { value: 'refinance', label: 'Refinancing', description: 'Refinance an existing RV loan', className: 'loan-type-3' }
];

const creditScoreOptions = [
  { value: '760-850', label: '760 - 850', description: 'Excellent', className: 'credit-score-1' },
  { value: '700-759', label: '700 - 759', description: 'Good', className: 'credit-score-2' },
  { value: '660-699', label: '660 - 699', description: 'Fair', className: 'credit-score-3' },
  { value: '620-659', label: '620 - 659', description: 'Fair', className: 'credit-score-4' },
  { value: '580-619', label: '580 - 619', description: 'Below Average', className: 'credit-score-5' },
  { value: '500-579', label: '500 - 579', description: 'Poor', className: 'credit-score-6' }
];

export function LoanCalculator() {
  const [currentStep, setCurrentStep] = useState(1);
  const [loanType, setLoanType] = useState('');
  const [loanAmount, setLoanAmount] = useState('');
  const [modelYear, setModelYear] = useState('');
  const [creditScore, setCreditScore] = useState('');
  
  const [calculatedAPR, setCalculatedAPR] = useState<number | null>(null);
  const [monthlyPayment, setMonthlyPayment] = useState<number | null>(null);
  const [term, setTerm] = useState<number | null>(null);

  const totalSteps = 5;

  useEffect(() => {
    // Calculate when we reach the results step
    if (currentStep === 5 && loanType && loanAmount && creditScore) {
      const amount = parseFloat(loanAmount.replace(/,/g, ''));
      
      if (amount >= 10000) {
        const rateInfo = rateLookup[loanType][creditScore];
        
        if (rateInfo) {
          let finalRate = rateInfo.baseRate;
          let finalTerm = rateInfo.term;
          
          // Adjust rate based on model year
          if (modelYear) {
            const year = parseInt(modelYear);
            const age = 2025 - year;
            if (age > 10) finalRate += 1.5;
            else if (age > 5) finalRate += 0.75;
            else if (age > 2) finalRate += 0.25;
          }
          
          // Calculate monthly payment
          const monthlyRate = finalRate / 100 / 12;
          const numPayments = finalTerm;
          const payment = (amount * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
                          (Math.pow(1 + monthlyRate, numPayments) - 1);
          
          setCalculatedAPR(finalRate);
          setMonthlyPayment(payment);
          setTerm(finalTerm);
        }
      }
    }
  }, [currentStep, loanType, loanAmount, modelYear, creditScore]);

  const formatCurrency = (value: string) => {
    const num = value.replace(/\D/g, '');
    if (!num) return '';
    return parseInt(num).toLocaleString();
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCurrency(e.target.value);
    setLoanAmount(formatted);
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canProceed = () => {
    if (currentStep === 1) return loanType !== '';
    if (currentStep === 2) return loanAmount !== '' && parseFloat(loanAmount.replace(/,/g, '')) >= 10000;
    if (currentStep === 3) return modelYear !== '';
    if (currentStep === 4) return creditScore !== '';
    return false;
  };

  const restartCalculator = () => {
    setCurrentStep(1);
    setLoanType('');
    setLoanAmount('');
    setModelYear('');
    setCreditScore('');
    setCalculatedAPR(null);
    setMonthlyPayment(null);
    setTerm(null);
  };

  return (
    <section className="rv-section rv-section-alt" id="calculator">
      <div className="rv-container">
        <div className="rv-calculator-intro">
          <h2 className="rv-heading-lg rv-heading-serif">RV Loan Payment Calculator</h2>
          <p className="rv-text-lg">
            Get an instant estimate of your monthly payment in just a few quick steps.
          </p>
        </div>

        <div className="rv-calculator-wrapper">
          {/* Progress Bar */}
          <div className="rv-calc-progress">
            <div className="rv-calc-progress-bar">
              <div 
                className="rv-calc-progress-fill" 
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              />
            </div>
            <div className="rv-calc-progress-text">
              Step {currentStep} of {totalSteps}
            </div>
          </div>

          {/* Step Content */}
          <div className="rv-calc-content">
            {/* Step 1: Loan Type */}
            {currentStep === 1 && (
              <div className="rv-calc-step">
                <h3 className="rv-calc-step-title">What type of financing do you need?</h3>
                <div className="rv-calc-options">
                  {loanTypeOptions.map((option) => (
                    <button
                      key={option.value}
                      className={`rv-calc-option ${option.className} ${loanType === option.value ? 'selected' : ''}`}
                      onClick={() => setLoanType(option.value)}
                    >
                      <div className="rv-calc-option-label">{option.label}</div>
                      <div className="rv-calc-option-desc">{option.description}</div>
                      {loanType === option.value && (
                        <CheckCircle className="rv-calc-option-check" size={24} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Loan Amount */}
            {currentStep === 2 && (
              <div className="rv-calc-step">
                <h3 className="rv-calc-step-title">How much do you want to finance?</h3>
                <div className="rv-calc-input-group">
                  <label htmlFor="amount" className="rv-calc-label">Loan Amount</label>
                  <div className="rv-calc-input-wrapper">
                    <span className="rv-calc-input-prefix">$</span>
                    <input
                      type="text"
                      id="amount"
                      value={loanAmount}
                      onChange={handleAmountChange}
                      placeholder="75,000"
                      className="rv-calc-input"
                      autoFocus
                    />
                  </div>
                  {loanAmount && parseFloat(loanAmount.replace(/,/g, '')) < 10000 && (
                    <div className="rv-calc-hint error">Minimum loan amount is $10,000</div>
                  )}
                  {!loanAmount && (
                    <div className="rv-calc-hint">Enter an amount between $10,000 - $500,000</div>
                  )}
                </div>
              </div>
            )}

            {/* Step 3: Model Year */}
            {currentStep === 3 && (
              <div className="rv-calc-step">
                <h3 className="rv-calc-step-title">What is the RV's model year?</h3>
                <div className="rv-calc-select-group">
                  <label htmlFor="year" className="rv-calc-label">Model Year</label>
                  <select
                    id="year"
                    value={modelYear}
                    onChange={(e) => setModelYear(e.target.value)}
                    className="rv-calc-select"
                    autoFocus
                  >
                    <option value="">Select year</option>
                    {modelYears.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                  <div className="rv-calc-hint">Newer RVs typically qualify for better rates</div>
                </div>
              </div>
            )}

            {/* Step 4: Credit Score */}
            {currentStep === 4 && (
              <div className="rv-calc-step">
                <h3 className="rv-calc-step-title">What's your estimated credit score range?</h3>
                <div className="rv-calc-options">
                  {creditScoreOptions.map((option) => (
                    <button
                      key={option.value}
                      className={`rv-calc-option ${option.className} ${creditScore === option.value ? 'selected' : ''}`}
                      onClick={() => setCreditScore(option.value)}
                    >
                      <div className="rv-calc-option-label">{option.label}</div>
                      <div className="rv-calc-option-desc">{option.description}</div>
                      {creditScore === option.value && (
                        <CheckCircle className="rv-calc-option-check" size={24} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 5: Results */}
            {currentStep === 5 && (
              <div className="rv-calc-step">
                <h3 className="rv-calc-step-title">Your Estimated Monthly Payment</h3>
                <div className="rv-calc-results">
                  <div className="rv-calc-result-main">
                    <div className="rv-calc-result-payment">
                      ${monthlyPayment ? Math.round(monthlyPayment).toLocaleString() : '—'}
                    </div>
                    <div className="rv-calc-result-label">per month</div>
                  </div>

                  <div className="rv-calc-result-details">
                    <div className="rv-calc-result-item">
                      <div className="rv-calc-result-item-label">Interest Rate (APR)</div>
                      <div className="rv-calc-result-item-value">
                        {calculatedAPR ? `${calculatedAPR.toFixed(2)}%` : '—'}
                      </div>
                    </div>
                    <div className="rv-calc-result-item">
                      <div className="rv-calc-result-item-label">Loan Term</div>
                      <div className="rv-calc-result-item-value">
                        {term ? `${term} months` : '—'}
                      </div>
                    </div>
                    <div className="rv-calc-result-item">
                      <div className="rv-calc-result-item-label">Loan Amount</div>
                      <div className="rv-calc-result-item-value">
                        ${loanAmount}
                      </div>
                    </div>
                  </div>

                  <div className="rv-calc-result-actions">
                    <a href="#apply" className="rv-btn rv-btn-primary rv-btn-large">
                      Apply Now
                      <ArrowRight size={20} style={{ marginLeft: '8px' }} />
                    </a>
                    <button onClick={restartCalculator} className="rv-calc-restart">
                      Start Over
                    </button>
                  </div>

                  <div className="rv-calc-result-disclaimer">
                    This is an estimate only. Actual rates and terms may vary based on creditworthiness, 
                    down payment, and other factors. Subject to credit approval.
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Navigation Buttons */}
          {currentStep < 5 && (
            <div className="rv-calc-nav">
              {currentStep > 1 && (
                <button onClick={handleBack} className="rv-calc-nav-btn secondary">
                  <ArrowLeft size={20} />
                  Back
                </button>
              )}
              <button 
                onClick={handleNext} 
                className="rv-calc-nav-btn primary"
                disabled={!canProceed()}
              >
                {currentStep === 4 ? 'See My Payment' : 'Continue'}
                <ArrowRight size={20} />
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
