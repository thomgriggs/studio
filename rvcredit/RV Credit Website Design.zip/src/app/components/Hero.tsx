import React from 'react';
import { ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import './Hero.css';

export function Hero() {
  return (
    <section className="rv-hero">
      <div className="rv-container">
        <div className="rv-hero-grid">
          <div className="rv-hero-content">
            <h1 className="rv-heading-xl rv-heading-serif">
              Finance Your Dream RV with Confidence
            </h1>
            <p className="rv-text-lg rv-hero-description">
              Whether you're buying new, used, or refinancing an existing RV loan, 
              we make RV financing simple and straightforward. Get pre-approved in minutes 
              and hit the open road sooner.
            </p>
            <div className="rv-hero-actions">
              <a href="#apply" className="rv-btn rv-btn-primary">
                Get Pre-Approved Now
                <ArrowRight size={20} style={{ marginLeft: '8px', display: 'inline-block', verticalAlign: 'middle' }} />
              </a>
              <a href="#calculator" className="rv-btn rv-btn-secondary">
                Calculate Payment
              </a>
            </div>
            <div className="rv-hero-trust">
              <p className="rv-trust-text">
                <strong>Trusted by thousands</strong> • No impact to credit score for pre-approval
              </p>
            </div>
          </div>
          <div className="rv-hero-image">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1548180934-f393c592740e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydiUyMHNjZW5pYyUyMG1vdW50YWluc3xlbnwxfHx8fDE3NjE3NzI3MDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="RV in scenic mountain area ready for financing"
              className="rv-hero-img"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
