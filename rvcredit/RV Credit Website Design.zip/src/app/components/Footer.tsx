import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram } from 'lucide-react';
import './Footer.css';
import RVCreditLogoWhite from './rv-credit-logo-white.svg';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="rv-footer">
      <div className="rv-container">
        <div className="rv-footer-grid">
          <div className="rv-footer-col">
            <img src={RVCreditLogoWhite} alt="RV Credit" className="rv-footer-logo-image" />
            <p className="rv-footer-description">
              Your trusted partner for RV financing. We help make your dream of owning 
              an RV a reality with competitive rates and flexible terms.
            </p>
            <div className="rv-footer-social">
              <a href="#facebook" aria-label="Facebook" className="rv-social-link">
                <Facebook size={20} />
              </a>
              <a href="#twitter" aria-label="Twitter" className="rv-social-link">
                <Twitter size={20} />
              </a>
              <a href="#instagram" aria-label="Instagram" className="rv-social-link">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          <div className="rv-footer-col">
            <h4 className="rv-footer-heading">Quick Links</h4>
            <ul className="rv-footer-links">
              <li><a href="#financing">Financing Options</a></li>
              <li><a href="#how-it-works">How It Works</a></li>
              <li><a href="#about">About Us</a></li>
              <li><a href="#faq">FAQ</a></li>
              <li><a href="#calculator">Payment Calculator</a></li>
            </ul>
          </div>

          <div className="rv-footer-col">
            <h4 className="rv-footer-heading">Resources</h4>
            <ul className="rv-footer-links">
              <li><a href="#buying-guide">RV Buying Guide</a></li>
              <li><a href="#blog">Blog & Tips</a></li>
              <li><a href="#reviews">Customer Reviews</a></li>
              <li><a href="#contact">Contact Support</a></li>
              <li><a href="#careers">Careers</a></li>
            </ul>
          </div>

          <div className="rv-footer-col">
            <h4 className="rv-footer-heading">Contact Us</h4>
            <ul className="rv-footer-contact">
              <li>
                <Phone size={18} />
                <span>1-800-555-0123</span>
              </li>
              <li>
                <Mail size={18} />
                <span>info@rvcredit.com</span>
              </li>
              <li>
                <MapPin size={18} />
                <span>Available Nationwide</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="rv-footer-bottom">
          <div className="rv-footer-legal">
            <p>&copy; {currentYear} RV Credit. All rights reserved.</p>
            <div className="rv-footer-legal-links">
              <a href="#privacy">Privacy Policy</a>
              <span className="rv-footer-divider">|</span>
              <a href="#terms">Terms of Service</a>
              <span className="rv-footer-divider">|</span>
              <a href="#accessibility">Accessibility</a>
            </div>
          </div>
          <p className="rv-footer-disclaimer">
            * Rates and terms subject to credit approval. Example rates shown for illustrative purposes only.
          </p>
        </div>
      </div>
    </footer>
  );
}
