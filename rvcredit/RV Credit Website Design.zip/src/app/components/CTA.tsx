import React from 'react';
import { ArrowRight } from 'lucide-react';
import { TopographicPattern } from './TopographicPattern';
import './CTA.css';

export function CTA() {
  return (
    <section className="rv-cta-section" id="apply">
      <TopographicPattern />
      <div className="rv-container">
        <div className="rv-cta-content">
          <h2 className="rv-heading-lg rv-heading-serif">Ready to Start Your RV Journey?</h2>
          <p className="rv-text-lg">
            Whether you're buying new, used, or refinancing, get pre-approved today and discover 
            how affordable RV ownership can be. Your adventure awaits – let's make it happen together.
          </p>
          <div className="rv-cta-actions">
            <a href="#application-form" className="rv-btn rv-btn-primary rv-btn-large">
              Apply for Financing
              <ArrowRight size={20} style={{ marginLeft: '8px', display: 'inline-block', verticalAlign: 'middle' }} />
            </a>
            <a href="tel:1-800-555-0123" className="rv-cta-phone">
              Or call us at <strong>1-800-555-0123</strong>
            </a>
          </div>
          <p className="rv-cta-note">
            Pre-qualification won't affect your credit score • Get an answer in minutes
          </p>
        </div>
      </div>
    </section>
  );
}
